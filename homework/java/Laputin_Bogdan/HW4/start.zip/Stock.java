package by.jrr.start;

public class Stock
{
    String name;
    double price;
    double minPrice;
    double maxPrice;

    public Stock(String name, double price)
    {
        this.name = name;
        this.price = price;
        this.minPrice = price;
        this.maxPrice = price;
    }

    public void updatePrice(double price)
    {
        if (price > this.maxPrice)
        {
            this.maxPrice = price;
        }
        else if (price < this.minPrice)
        {
            this.minPrice = price;
        }
        this.price = price;
    }

    public void printInformation()
    {
        System.out.print("Company=\""+ this.name+ "\", Current Price=");
        System.out.printf("%.0f", this.price);
        System.out.print(", Min Price=");
        System.out.printf("%.0f", this.minPrice);
        System.out.print(", Max Price=");
        System.out.printf("%.0f", this.maxPrice);
    }
}

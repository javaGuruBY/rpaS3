package by.jrr.start;

import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class StockTest {

    Stock shop;

    @Before
    public void setup(){
        shop = new Stock("Apple", 10000);
    }

    @After
    public void print()
    {
        shop.printInformation();
    }

    @Test
    public void test1()
    {
        Stock actual = new Stock("Apple", 10000);
        actual.maxPrice = 10000000;
        actual.minPrice = 10000;
        actual.price = 10000000;
        shop.updatePrice(100000);
        shop.updatePrice(1000000);
        shop.updatePrice(10000000);
        Stock expected = shop;
        assertEquals(expected.name, actual.name);
        assertEquals(expected.price, actual.price, 2);
        assertEquals(expected.maxPrice, actual.maxPrice, 2);
        assertEquals(expected.minPrice, actual.minPrice, 2);
    }

    @Test
    public void test2()
    {
        Stock actual = new Stock("Apple", 10000);
        actual.maxPrice = 10000;
        actual.minPrice = 1;
        actual.price = 3;
        shop.updatePrice(1);
        shop.updatePrice(2);
        shop.updatePrice(3);
        Stock expected = shop;
        assertEquals(expected.name, actual.name);
        assertEquals(expected.price, actual.price, 2);
        assertEquals(expected.maxPrice, actual.maxPrice, 2);
        assertEquals(expected.minPrice, actual.minPrice, 2);
    }

    @Test
    public void test3()
    {
        Stock actual = new Stock("Apple", 10000);
        actual.maxPrice = 10001;
        actual.minPrice = 999.99;
        actual.price = 10001;
        shop.updatePrice(999.99);
        shop.updatePrice(9999.99);
        shop.updatePrice(10001);
        Stock expected = shop;
        assertEquals(expected.name, actual.name);
        assertEquals(expected.price, actual.price, 2);
        assertEquals(expected.maxPrice, actual.maxPrice, 2);
        assertEquals(expected.minPrice, actual.minPrice, 2);
    }
}
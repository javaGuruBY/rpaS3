package user;

public class User
{
    String login;
    String password;
    boolean ban;
    int attempts;

    public User(String login, String password)
    {
        this.login = login;
        this.password = password;
        this.ban = false;
        this.attempts = 0;
    }

    public void resetAttempts()
    {
        this.attempts = 0;
    }

    public void block()
    {
        this.ban = true;
    }
}
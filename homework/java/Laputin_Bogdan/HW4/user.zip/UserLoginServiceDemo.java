package user;

public class UserLoginServiceDemo {
    public static void main(String[] args)
    {
        User user1 = new User("Anton", "87654321");
        UserLoginService service1 = new UserLoginService();
        boolean tmp = service1.login(user1, "88888888");
        if (!tmp)
        {
            if (user1.ban)
            {
                System.out.println("You have exceeded the available number of attempts");
            }
            else
            {
                System.out.println("Incorrect username or password, try again");
            }
        }
        else
        {
            System.out.println("Successful login");
        }
    }
}
package user;

public class UserLoginService
{
    boolean login(User user, String password)
    {
        if (!user.ban)
        {
            if (user.password == password)
            {
                user.resetAttempts();
                return true;
            }
            else
            {
                user.attempts ++;
                if (user.attempts == 3)
                    user.block();
                return false;
            }
        }
        else return false;
    }
}

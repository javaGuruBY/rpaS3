package user;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class UserTest {

    User user00;

    @Before
    public void setup()
    {
        user00 = new User("NaGiB4Uk", "12345678");
    }

    @Test
    public void resetAttempts()
    {
        int expected = 0;
        user00.resetAttempts();
        int actual = user00.attempts;
        assertEquals(expected, actual);
    }

    @Test
    public void block()
    {
        user00.block();
        boolean actual = user00.ban;
        assertTrue(actual);
    }
}
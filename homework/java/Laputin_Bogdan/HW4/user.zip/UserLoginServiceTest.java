package user;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class UserLoginServiceTest {

    UserLoginService service;
    User user01;

    @Before
    public void setup()
    {
        service = new UserLoginService();
        user01 = new User("NaGiB4Uk", "12345678");
    }

    @Test
    public void correctPassword()
    {
        boolean actual = service.login(user01, "12345678");
        assertTrue(actual);
    }

    @Test
    public void wrongPassword()
    {
        boolean actual = service.login(user01, "123456789");
        assertFalse(actual);
    }

    @Test
    public void attemptsNumberExceeded()
    {
        boolean actual = service.login(user01, "12345");
        actual = service.login(user01, "123456");
        actual = service.login(user01, "1234567");
        actual = service.login(user01, "12345678");
        assertFalse(actual);
    }

    @Test
    public void attemptsNumberNotExceeded()
    {
        boolean actual = service.login(user01, "123456");
        actual = service.login(user01, "1234567");
        actual = service.login(user01, "12345678");
        assertTrue(actual);
    }
}